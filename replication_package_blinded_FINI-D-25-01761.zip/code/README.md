# Code Folder (Blinded Review Safe)

## What this does
These scripts reproduce Section 3–4 tables/figures from the harmonized NYSE dataset using only public, blinded files.

## How to run (local)
1. Create a Python env with:
   pip install pandas numpy scipy statsmodels pyyaml matplotlib openpyxl xlsxwriter
2. Ensure `../data/` contains:
   - firms_harmonized.csv
   - evidence_corpus_sentences.csv
   - language_benchmark_counts.csv
3. From this `/code` folder, run:
   python run_all.py

Outputs:
- `../data/analysis_results_MIN_REPLICATION.xlsx` (tables + statistics)
- `../figures/*.png` (figures for the manuscript and appendix)

## Notes
- Deterministic pipeline (no external calls). Random seed is in 00_config.yaml.
- All scripts are blinded (no author names, no institutional paths).
