# Outcome-Claims Index (OCI) scanning and roll-ups.
# Uses precomputed flags if present; otherwise generates from text.
# Outputs (sheets):
#   - outcome_claims_crosstab
#   - outcome_claims_crosstab_share

import sys, re
from pathlib import Path
import numpy as np
import pandas as pd
import yaml

def load_config(path):
    with open(path, "r") as f:
        return yaml.safe_load(f)

def ensure_flag_cols(df):
    needed = ["claim_pct","claim_perf","claim_risk","claim_eff","claim_fin","claim_improve","claims_any"]
    return all(c in df.columns for c in needed)

PCT_RE = re.compile(r"\b\d+(?:\.\d+)?\s*%")  # matches percentages like 5% or 2.3%
PERF_TERMS = re.compile(r"\b(accuracy|precision|recall|f1|auc|roc|rmse|mae|mape|r2|r\^2)\b", re.I)
RISK_TERMS = re.compile(r"\b(default|delinquenc|charge[- ]?off|fraud|loss rate|false positive|false negative)\b", re.I)
EFF_TERMS = re.compile(r"\b(latency|throughput|cycle time|turnaround|hours|minutes|seconds)\b", re.I)
FIN_TERMS = re.compile(r"\b(roi|basis points|bps|opex|capex|revenue impact|cost savings)\b", re.I)
IMPROVE_TERMS = re.compile(r"\b(improv|reduc|increase|decreas)\w*", re.I)

def flag_row(text):
    t = str(text)
    pct = 1 if PCT_RE.search(t) else 0
    perf = 1 if PERF_TERMS.search(t) else 0
    risk = 1 if RISK_TERMS.search(t) else 0
    eff  = 1 if EFF_TERMS.search(t) else 0
    fin  = 1 if FIN_TERMS.search(t) else 0
    imp  = 1 if IMPROVE_TERMS.search(t) else 0
    return pct, perf, risk, eff, fin, imp

def main(cfg_path="00_config.yaml"):
    cfg = load_config(cfg_path)
    data_dir = Path(cfg["paths"]["data_dir"]).resolve()
    out_xlsx = data_dir / cfg["files"]["analysis_out"]
    ev_csv = data_dir / cfg["files"]["evidence"]

    ev = pd.read_csv(ev_csv)
    if not ensure_flag_cols(ev):
        flags = ev["evidence_sentence"].apply(flag_row).apply(pd.Series)
        flags.columns = ["claim_pct","claim_perf","claim_risk","claim_eff","claim_fin","claim_improve"]
        ev = pd.concat([ev, flags], axis=1)
        ev["claims_any"] = ev[["claim_pct","claim_perf","claim_risk","claim_eff","claim_fin","claim_improve"]].max(axis=1)
    else:
        cols = ["claim_pct","claim_perf","claim_risk","claim_eff","claim_fin","claim_improve","claims_any"]
        ev[cols] = ev[cols].fillna(0).astype(int)

    ev["any_flag"] = ev[["claim_pct","claim_perf","claim_risk","claim_eff","claim_fin","claim_improve"]].max(axis=1)
    ct = pd.crosstab(ev["subsector"], ev["any_flag"]).reset_index().rename(columns={0:"no_claim",1:"any_claim"})
    share = ct.copy()
    if "no_claim" not in share.columns: share["no_claim"] = 0
    if "any_claim" not in share.columns: share["any_claim"] = 0
    denom = (share["no_claim"] + share["any_claim"]).replace(0, np.nan)
    share["no_claim_share"] = share["no_claim"] / denom
    share["any_claim_share"] = share["any_claim"] / denom

    with pd.ExcelWriter(out_xlsx, mode="a", engine="openpyxl", if_sheet_exists="replace") as w:
        ct.to_excel(w, sheet_name="outcome_claims_crosstab", index=False)
        share.to_excel(w, sheet_name="outcome_claims_crosstab_share", index=False)

    print(f"[04] Wrote OCI cross-tabs to {out_xlsx}")

if __name__ == "__main__":
    cfg_path = sys.argv[1] if len(sys.argv) > 1 else "00_config.yaml"
    main(cfg_path)