# Build or validate `firms_harmonized.csv` from raw inputs or existing workbooks.
# - Reads config from 00_config.yaml
# - If `firms_harmonized.csv` exists in /data, validates required columns.
# - Else tries to build from a harmonized XLSX if present; otherwise writes an empty template.

import sys, os
from pathlib import Path
import pandas as pd
import yaml

def load_config(path):
    with open(path, "r") as f:
        return yaml.safe_load(f)

def ensure_required_columns(df, required):
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    return df

def main(cfg_path="00_config.yaml"):
    cfg = load_config(cfg_path)
    data_dir = Path(cfg["paths"]["data_dir"]).resolve()
    data_dir.mkdir(parents=True, exist_ok=True)

    firms_csv = data_dir / cfg["files"]["firms"]
    required_cols = ["ticker","standardized_name","subsector","disclosure_status","evidence_count","channel_breadth"]

    if firms_csv.exists():
        df = pd.read_csv(firms_csv)
        df = ensure_required_columns(df, required_cols)
        print(f"[01] Validated existing {firms_csv} with {df.shape[0]} rows.")
        return

    harm_xlsx = data_dir / "analysis_results_2026-01-06_HARMONIZED.xlsx"
    if harm_xlsx.exists():
        try:
            raw = pd.read_excel(harm_xlsx, sheet_name="firms_harmonized")
            raw.columns = [c.lower() for c in raw.columns]
            out = raw.rename(columns={
                "firm_id":"ticker",
                "firm_name":"standardized_name",
                "subsector_canon":"subsector"
            })
            if "evidence_count" not in out.columns:
                out["evidence_count"] = 0
            if "channel_breadth" not in out.columns:
                out["channel_breadth"] = 0
            out = out[required_cols]
            out.to_csv(firms_csv, index=False)
            print(f"[01] Built {firms_csv} from {harm_xlsx}.")
            return
        except Exception as e:
            print(f"[01] Could not build from {harm_xlsx} due to: {e}")

    empty = pd.DataFrame(columns=required_cols)
    empty.to_csv(firms_csv, index=False)
    print(f"[01] Created empty template {firms_csv}; please populate and re-run.")

if __name__ == "__main__":
    cfg_path = sys.argv[1] if len(sys.argv) > 1 else "00_config.yaml"
    main(cfg_path)