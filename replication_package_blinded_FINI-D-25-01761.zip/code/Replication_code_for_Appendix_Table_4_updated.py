"""
Replication code for Appendix Table 4
------------------------------------

This script reproduces the construction of Appendix Table 4 as described
in Section 3 (Data and Methods). It:

1. Loads a sentence-level replication corpus.
2. Detects mentions of Python libraries / platforms using regex.
3. Aggregates detections by subsector to identify dominant libraries.
4. Selects exemplar firms per subsector with the highest evidence counts.
5. Outputs a three-column exhibit suitable for Appendix Table 4:
   - Subsector (N)
   - Dominant libraries/frameworks
   - Illustrative company deployments
"""

import pandas as pd
import re
from pathlib import Path


# -------------------------------------------------------------------
# CONFIG: paths and column names
# -------------------------------------------------------------------
CORPUS_PATH = Path("data/sentence_level_corpus.csv")
OUTPUT_TABLE_PATH = Path("output/appendix_table_4.csv")

COL_SUBSECTOR = "subsector"
COL_COMPANY = "company"
COL_TICKER = "ticker"          # optional but recommended
COL_SENTENCE = "sentence_text"

# number of dominant libraries per subsector in the table
TOP_N_LIBS = 5

# number of exemplar firms per subsector
EXEMPLARS_PER_SUBSECTOR = 3


# -------------------------------------------------------------------
# 1. Load replication corpus
# -------------------------------------------------------------------
def load_corpus(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    required_cols = {COL_SUBSECTOR, COL_COMPANY, COL_SENTENCE}
    missing = required_cols - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns in corpus: {missing}")
    return df


# -------------------------------------------------------------------
# 2. Define library / platform regex patterns
#    Keys are the nice labels you want in the table.
#    Values are case-insensitive regex patterns.
# -------------------------------------------------------------------
LIBRARY_PATTERNS = {
    "pandas": r"\bpandas\b",
    "NumPy": r"\bnumpy\b|\bnp\b",
    "scikit-learn": r"\bscikit[- ]?learn\b|\bsklearn\b",
    "XGBoost": r"\bxgboost\b",
    "LightGBM": r"\blightgbm\b",
    "TensorFlow": r"\btensorflow\b",
    "PyTorch": r"\bpytorch\b|\btorch\.?(?!\w)",
    "spaCy": r"\bspacy\b",
    "Transformers": r"\btransformers?\b",
    "PyOD": r"\bpyod\b",
    "NetworkX": r"\bnetworkx\b",
    "PyTorch Geometric": r"\bpytorch[ -]?geometric\b",
    "GS Quant": r"\bgs[ _-]?quant\b",
    "Aladdin": r"\baladdin\b",
}


# -------------------------------------------------------------------
# 3. Sentence-level detection of libraries/platforms
#    Returns one row per (subsector, company, ticker, library) detection.
# -------------------------------------------------------------------
def detect_libraries(df: pd.DataFrame) -> pd.DataFrame:
    detections = []

    for _, row in df.iterrows():
        text = str(row[COL_SENTENCE])
        subsector = row[COL_SUBSECTOR]
        company = row[COL_COMPANY]
        ticker = row.get(COL_TICKER, pd.NA)

        for lib_label, pattern in LIBRARY_PATTERNS.items():
            if re.search(pattern, text, flags=re.IGNORECASE):
                detections.append(
                    {
                        "subsector": subsector,
                        "company": company,
                        "ticker": ticker,
                        "library": lib_label,
                    }
                )

    det_df = pd.DataFrame(detections)
    if det_df.empty:
        raise ValueError("No library detections found. Check regex patterns and corpus.")
    return det_df


# -------------------------------------------------------------------
# 4. Dominant libraries per subsector
# -------------------------------------------------------------------
def summarise_dominant_libraries(det_df: pd.DataFrame, top_n: int) -> pd.DataFrame:
    library_counts = (
        det_df.groupby(["subsector", "library"])
        .size()
        .reset_index(name="n_mentions")
    )

    dominant = (
        library_counts.sort_values(["subsector", "n_mentions"], ascending=[True, False])
        .groupby("subsector")
        .head(top_n)
    )

    dominant_libs_str = (
        dominant.sort_values(["subsector", "n_mentions"], ascending=[True, False])
        .groupby("subsector")["library"]
        .apply(lambda s: ", ".join(s))
        .reset_index(name="Dominant libraries/frameworks")
    )
    return dominant_libs_str


# -------------------------------------------------------------------
# 5. Subsector N: number of distinct firms in the corpus per subsector
# -------------------------------------------------------------------
def compute_subsector_n(df: pd.DataFrame) -> pd.DataFrame:
    subsector_n = (
        df.groupby("subsector")[COL_COMPANY]
        .nunique()
        .reset_index(name="N")
    )
    return subsector_n


# -------------------------------------------------------------------
# 6. Exemplar firms: 2–3 per subsector with highest evidence counts
# -------------------------------------------------------------------
def format_company_label(row) -> str:
    ticker = row["ticker"]
    if pd.notna(ticker) and str(ticker).strip() != "":
        return f"{row['company']} ({ticker})"
    return str(row["company"])


def select_exemplars(det_df: pd.DataFrame, exemplars_per_subsector: int) -> pd.DataFrame:
    evidence_counts = (
        det_df.groupby(["subsector", "company", "ticker"])
        .size()
        .reset_index(name="n_mentions")
    )

    exemplar_df = (
        evidence_counts.sort_values(["subsector", "n_mentions"], ascending=[True, False])
        .groupby("subsector")
        .head(exemplars_per_subsector)
    )

    exemplar_df["company_label"] = exemplar_df.apply(format_company_label, axis=1)

    exemplars_str = (
        exemplar_df.groupby("subsector")["company_label"]
        .apply(lambda s: "; ".join(s))
        .reset_index(name="Illustrative company deployments")
    )
    return exemplars_str


# -------------------------------------------------------------------
# 7. Build Appendix Table 4
# -------------------------------------------------------------------
def build_appendix_table_4b(df: pd.DataFrame) -> pd.DataFrame:
    det_df = detect_libraries(df)
    subsector_n = compute_subsector_n(df)
    dominant_libs_str = summarise_dominant_libraries(det_df, TOP_N_LIBS)
    exemplars_str = select_exemplars(det_df, EXEMPLARS_PER_SUBSECTOR)

    table4b = (
        subsector_n
        .merge(dominant_libs_str, on="subsector", how="outer")
        .merge(exemplars_str, on="subsector", how="outer")
    )

    table4b = table4b.rename(columns={"subsector": "Subsector"})
    table4b = table4b.sort_values("Subsector").reset_index(drop=True)
    return table4b


# -------------------------------------------------------------------
# 8. Main entry point
# -------------------------------------------------------------------
def main():
    df = load_corpus(CORPUS_PATH)

    table4b = build_appendix_table_4b(df)

    OUTPUT_TABLE_PATH.parent.mkdir(parents=True, exist_ok=True)
    table4b.to_csv(OUTPUT_TABLE_PATH, index=False)

    print("Appendix Table 4 written to:", OUTPUT_TABLE_PATH)
    print(table4b)


if __name__ == "__main__":
    main()
