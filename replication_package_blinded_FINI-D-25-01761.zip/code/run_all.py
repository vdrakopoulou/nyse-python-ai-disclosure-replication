# Convenience runner to execute steps 01→06 using the configured paths.
# Usage: python run_all.py [00_config.yaml]

import sys, subprocess

def run(cmd):
    print(f"--> {cmd}")
    rc = subprocess.call(cmd, shell=True)
    if rc != 0:
        raise SystemExit(rc)

def main(cfg="00_config.yaml"):
    run(f"python 01_build_harmonized_firms.py {cfg}")
    run(f"python 02_compute_crosstabs_and_posthoc.py {cfg}")
    run(f"python 03_visibility_weighting_and_logit.py {cfg}")
    run(f"python 04_outcome_claims_index_scan.py {cfg}")
    run(f"python 05_language_benchmark.py {cfg}")
    run(f"python 06_figures.py {cfg}")
    print('Done. Outputs written to paths defined in 00_config.yaml.')

if __name__ == '__main__':
    cfg = sys.argv[1] if len(sys.argv) > 1 else "00_config.yaml"
    main(cfg)