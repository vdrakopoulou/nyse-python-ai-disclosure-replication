# Produce named-language counts by subsector and totals for Appendix Table S4.6.
# Outputs (sheets):
#   - other_language_by_sub
#   - other_language_totals

import sys
from pathlib import Path
import pandas as pd
import yaml

def load_config(path):
    with open(path, "r") as f:
        return yaml.safe_load(f)

def main(cfg_path="00_config.yaml"):
    cfg = load_config(cfg_path)
    data_dir = Path(cfg["paths"]["data_dir"]).resolve()
    out_xlsx = data_dir / cfg["files"]["analysis_out"]
    lang_csv = data_dir / cfg["files"]["language"]

    df = pd.read_csv(lang_csv)
    by_sub = (df.groupby("subsector")[["count_python","count_r","count_java","count_sas","count_scala","count_matlab"]]
                .sum().reset_index())
    totals = by_sub.drop(columns=["subsector"]).sum().to_frame(name="total").reset_index().rename(columns={"index":"language"})
    with pd.ExcelWriter(out_xlsx, mode="a", engine="openpyxl", if_sheet_exists="replace") as w:
        by_sub.to_excel(w, sheet_name="other_language_by_sub", index=False)
        totals.to_excel(w, sheet_name="other_language_totals", index=False)

    print(f"[05] Wrote language counts to {out_xlsx}")

if __name__ == "__main__":
    cfg_path = sys.argv[1] if len(sys.argv) > 1 else "00_config.yaml"
    main(cfg_path)