# Export figures using matplotlib only (no seaborn, no color specifications).
# - status_counts.png
# - status_by_subsector_heatmap.png
# - library_by_subsector_heatmap.png
# - evidence_timeline_by_year.png

import sys
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import yaml

def load_config(path):
    with open(path, "r") as f:
        return yaml.safe_load(f)

def main(cfg_path="00_config.yaml"):
    cfg = load_config(cfg_path)
    data_dir = Path(cfg["paths"]["data_dir"]).resolve()
    figs_dir = Path(cfg["paths"]["out_figures"]).resolve()
    figs_dir.mkdir(parents=True, exist_ok=True)

    firms_csv = data_dir / cfg["files"]["firms"]
    ev_csv = data_dir / cfg["files"]["evidence"]
    lang_csv = data_dir / cfg["files"]["language"]

    df = pd.read_csv(firms_csv)
    ev = pd.read_csv(ev_csv)
    lang = pd.read_csv(lang_csv)

    # 1) status counts
    fig1_path = figs_dir / "status_counts.png"
    counts = df["disclosure_status"].value_counts()
    plt.figure()
    counts.plot(kind="bar")
    plt.title("Disclosure Status Counts")
    plt.xlabel("Status")
    plt.ylabel("Count")
    plt.tight_layout()
    plt.savefig(fig1_path, dpi=300)
    plt.close()

    # 2) status by subsector heatmap (share)
    fig2_path = figs_dir / "status_by_subsector_heatmap.png"
    ct = pd.crosstab(df["subsector"], df["disclosure_status"])
    share = (ct.T / ct.sum(axis=1)).T
    plt.figure()
    plt.imshow(share.values, aspect="auto")
    plt.xticks(range(share.shape[1]), share.columns, rotation=45, ha="right")
    plt.yticks(range(share.shape[0]), share.index)
    plt.title("Disclosure Status by Subsector (Share)")
    plt.colorbar()
    plt.tight_layout()
    plt.savefig(fig2_path, dpi=300)
    plt.close()

    # 3) named-language mentions by subsector
    fig3_path = figs_dir / "library_by_subsector_heatmap.png"
    by_sub = (lang.groupby("subsector")[["count_python","count_r","count_java","count_sas","count_scala","count_matlab"]]
                .sum())
    plt.figure()
    plt.imshow(by_sub.values, aspect="auto")
    plt.xticks(range(by_sub.shape[1]), by_sub.columns, rotation=45, ha="right")
    plt.yticks(range(by_sub.shape[0]), by_sub.index)
    plt.title("Named-Language Mentions by Subsector")
    plt.colorbar()
    plt.tight_layout()
    plt.savefig(fig3_path, dpi=300)
    plt.close()

    # 4) evidence timeline by year
    fig4_path = figs_dir / "evidence_timeline_by_year.png"
    ev["year"] = pd.to_datetime(ev["retrieval_date"], errors="coerce").dt.year
    timeline = ev.groupby("year").size().rename("count").reset_index()
    plt.figure()
    plt.plot(timeline["year"], timeline["count"], marker="o")
    plt.title("Evidence Rows by Year")
    plt.xlabel("Year")
    plt.ylabel("Count")
    plt.tight_layout()
    plt.savefig(fig4_path, dpi=300)
    plt.close()

    print(f"[06] Saved figures to {figs_dir}")

if __name__ == "__main__":
    cfg_path = sys.argv[1] if len(sys.argv) > 1 else "00_config.yaml"
    main(cfg_path)