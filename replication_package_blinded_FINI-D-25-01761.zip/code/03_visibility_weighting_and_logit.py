# Compute inverse-visibility weighted shares and a logistic model with subsector indicators.
# Outputs (sheets in analysis_out workbook):
#   - weighted_overall
#   - weighted_explicit_by_sub
#   - logit_ORs

import sys
from pathlib import Path
import numpy as np
import pandas as pd
import yaml

def load_config(path):
    with open(path, "r") as f:
        return yaml.safe_load(f)

def inv_weight(evidence_count):
    return 1.0 / (1.0 + float(evidence_count))

def fit_logit_statsmodels(df, cfg):
    try:
        import statsmodels.api as sm
        y = df["explicit_flag"]
        X = pd.get_dummies(df["subsector"], drop_first=True)
        X["log1p_evidence"] = np.log1p(df["evidence_count"])
        X = sm.add_constant(X, has_constant='add')
        if cfg["analysis"]["logit"].get("regularized", True):
            res = sm.Logit(y, X).fit_regularized(maxiter=200)
        else:
            res = sm.Logit(y, X).fit(disp=False, maxiter=200)
        coefs = res.params
        ors = np.exp(coefs)
        try:
            se = res.bse
            ci_lo = np.exp(coefs - 1.96*se)
            ci_hi = np.exp(coefs + 1.96*se)
        except Exception:
            se = pd.Series(index=coefs.index, dtype=float)
            ci_lo = pd.Series(index=coefs.index, dtype=float)
            ci_hi = pd.Series(index=coefs.index, dtype=float)
        out = pd.DataFrame({
            "term": coefs.index,
            "coef": coefs.values,
            "OR": ors.values,
            "OR_95CI_lo": ci_lo.values,
            "OR_95CI_hi": ci_hi.values
        })
        return out
    except Exception as e:
        print("[03] statsmodels not available or failed:", e)
        try:
            from sklearn.linear_model import LogisticRegression
            X = pd.get_dummies(df["subsector"], drop_first=True)
            X["log1p_evidence"] = np.log1p(df["evidence_count"])
            y = df["explicit_flag"]
            model = LogisticRegression(penalty="l2", C=1.0, solver="liblinear", max_iter=200)
            model.fit(X, y)
            coefs = pd.Series(model.coef_[0], index=X.columns)
            ors = np.exp(coefs)
            out = pd.DataFrame({"term":coefs.index, "coef":coefs.values, "OR":ors.values})
            out = pd.concat([pd.DataFrame({"term":["intercept"], "coef":[model.intercept_[0]], "OR":[float(np.exp(model.intercept_[0]))]}) , out], ignore_index=True)
            return out
        except Exception as e2:
            print("[03] sklearn logistic regression failed:", e2)
            return pd.DataFrame(columns=["term","coef","OR"])

def main(cfg_path="00_config.yaml"):
    cfg = load_config(cfg_path)
    data_dir = Path(cfg["paths"]["data_dir"]).resolve()
    out_xlsx = data_dir / cfg["files"]["analysis_out"]
    firms_csv = data_dir / cfg["files"]["firms"]

    df = pd.read_csv(firms_csv)
    df["explicit_flag"] = (df["disclosure_status"].astype(str).str.lower()=="explicit_python").astype(int)

    df["w"] = df["evidence_count"].apply(inv_weight)
    w_total = df["w"].sum()
    w_exp = (df["explicit_flag"] * df["w"]).sum()
    weighted_overall = pd.DataFrame({"metric":["weighted_explicit_share_overall"], "value":[w_exp / w_total if w_total>0 else float("nan")]})

    rows = []
    for sub, g in df.groupby("subsector"):
        wt = g["w"].sum()
        we = (g["explicit_flag"]*g["w"]).sum()
        rows.append({"subsector":sub, "weighted_explicit_share": (we/wt if wt>0 else float("nan")), "n": int(g.shape[0])})
    weighted_by_sub = pd.DataFrame(rows).sort_values("subsector")

    logit_ors = fit_logit_statsmodels(df, cfg)

    with pd.ExcelWriter(out_xlsx, mode="a", engine="openpyxl", if_sheet_exists="replace") as w:
        weighted_overall.to_excel(w, sheet_name="weighted_overall", index=False)
        weighted_by_sub.to_excel(w, sheet_name="weighted_explicit_by_sub", index=False)
        if not logit_ors.empty:
            logit_ors.to_excel(w, sheet_name="logit_ORs", index=False)

    print(f"[03] Wrote weighted shares and logistic ORs to {out_xlsx}")

if __name__ == "__main__":
    cfg_path = sys.argv[1] if len(sys.argv) > 1 else "00_config.yaml"
    main(cfg_path)