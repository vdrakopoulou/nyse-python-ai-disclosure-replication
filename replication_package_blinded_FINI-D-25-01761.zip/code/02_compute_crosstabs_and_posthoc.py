# Compute cross-tabs and post-hoc analyses for disclosure_status by subsector.
# Outputs (sheets in analysis_out workbook):
#   - summary_counts
#   - status_by_subsector_counts
#   - status_by_subsector_share
#   - chi_square_test
#   - posthoc_BH_sig
#   - std_residuals

import sys
from pathlib import Path
import itertools
import numpy as np
import pandas as pd
import yaml
from scipy.stats import chi2_contingency, norm

def load_config(path):
    with open(path, "r") as f:
        return yaml.safe_load(f)

def ztest_two_proportions(x1, n1, x2, n2):
    p_pool = (x1 + x2) / (n1 + n2) if (n1 + n2) > 0 else 0.0
    se = np.sqrt(p_pool * (1 - p_pool) * (1/n1 + 1/n2)) if n1>0 and n2>0 else np.nan
    if se == 0 or np.isnan(se):
        return np.nan, np.nan
    z = (x1/n1 - x2/n2) / se
    p = 2 * (1 - norm.cdf(abs(z)))
    return z, p

def bh_adjust(pvals, alpha=0.05):
    p = np.array(pvals, dtype=float)
    n = p.size
    order = np.argsort(p)
    ranked = np.empty_like(order)
    ranked[order] = np.arange(1, n+1)
    adj = p * n / ranked
    adj_sorted = adj[order]
    for i in range(n-2, -1, -1):
        adj_sorted[i] = min(adj_sorted[i], adj_sorted[i+1])
    adj_final = np.empty_like(adj_sorted)
    adj_final[order] = adj_sorted
    reject = adj_final <= alpha
    return reject, adj_final

def main(cfg_path="00_config.yaml"):
    cfg = load_config(cfg_path)
    data_dir = Path(cfg["paths"]["data_dir"]).resolve()
    out_xlsx = data_dir / cfg["files"]["analysis_out"]
    firms_csv = data_dir / cfg["files"]["firms"]

    df = pd.read_csv(firms_csv)
    df["disclosure_status"] = df["disclosure_status"].astype(str).str.lower()
    df["subsector"] = df["subsector"].astype(str)

    summary_counts = df["disclosure_status"].value_counts().rename_axis("status").reset_index(name="count")
    summary_counts["share"] = summary_counts["count"] / summary_counts["count"].sum()

    ctab = pd.crosstab(df["subsector"], df["disclosure_status"]).reset_index()
    share = ctab.copy()
    cols = [c for c in share.columns if c != "subsector"]
    share[cols] = (share[cols].T / share[cols].sum(axis=1)).T

    cont = pd.crosstab(df["subsector"], df["disclosure_status"])
    chi2, p, dof, expected = chi2_contingency(cont.values)
    chi_df = pd.DataFrame({
        "chi2":[chi2],
        "p_value":[p],
        "dof":[dof],
        "N":[int(cont.values.sum())]
    })

    O = cont.values
    E = expected
    row_tot = O.sum(axis=1, keepdims=True)
    col_tot = O.sum(axis=0, keepdims=True)
    N = O.sum()
    row_prop = row_tot / N
    col_prop = col_tot / N
    denom = (E * (1 - row_prop) * (1 - col_prop))
    with np.errstate(divide='ignore', invalid='ignore'):
        std_resid = (O - E) / np.sqrt(denom)
    std_resid_df = pd.DataFrame(std_resid, index=cont.index, columns=cont.columns).reset_index().rename(columns={"index":"subsector"})

    df["explicit_flag"] = (df["disclosure_status"] == "explicit_python").astype(int)
    pairs = list(itertools.combinations(sorted(df["subsector"].unique()), 2))
    rows = []
    for a,b in pairs:
        na = (df["subsector"]==a).sum()
        nb = (df["subsector"]==b).sum()
        xa = df.loc[df["subsector"]==a, "explicit_flag"].sum()
        xb = df.loc[df["subsector"]==b, "explicit_flag"].sum()
        z, pval = ztest_two_proportions(xa, na, xb, nb)
        rows.append({"subsector_a":a,"subsector_b":b,"n_a":na,"n_b":nb,"x_a":xa,"x_b":xb,"z":z,"p_raw":pval})
    post = pd.DataFrame(rows)
    if not post.empty:
        reject, padj = bh_adjust(post["p_raw"].fillna(1.0).values, alpha=cfg["analysis"]["bh_alpha"])
        post["p_bh"] = padj
        post["reject_bh"] = reject
        post = post.sort_values("p_bh")

    with pd.ExcelWriter(out_xlsx, engine="xlsxwriter") as w:
        summary_counts.to_excel(w, sheet_name="summary_counts", index=False)
        ctab.to_excel(w, sheet_name="status_by_subsector_counts", index=False)
        share.to_excel(w, sheet_name="status_by_subsector_share", index=False)
        chi_df.to_excel(w, sheet_name="chi_square_test", index=False)
        std_resid_df.to_excel(w, sheet_name="std_residuals", index=False)
        if not post.empty:
            post.to_excel(w, sheet_name="posthoc_BH_sig", index=False)

    print(f"[02] Wrote cross-tabs and tests to {out_xlsx}")

if __name__ == "__main__":
    cfg_path = sys.argv[1] if len(sys.argv) > 1 else "00_config.yaml"
    main(cfg_path)